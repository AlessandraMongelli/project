RUNTIME_OUTPUT_DIRECTORY
------------------------

.. |XXX| replace:: :ref:`RUNTIME <Runtime Output Artifacts>`
.. |xxx| replace:: runtime
.. |CMAKE_XXX_OUTPUT_DIRECTORY| replace:: :variable:`CMAKE_RUNTIME_OUTPUT_DIRECTORY`
.. include:: XXX_OUTPUT_DIRECTORY.txt

See also the :prop_tgt:`RUNTIME_OUTPUT_DIRECTORY_<CONFIG>` target property.
