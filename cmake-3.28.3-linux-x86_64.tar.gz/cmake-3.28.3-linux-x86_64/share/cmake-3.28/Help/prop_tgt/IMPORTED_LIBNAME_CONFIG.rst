IMPORTED_LIBNAME_<CONFIG>
-------------------------

.. versionadded:: 3.8

<CONFIG>-specific version of :prop_tgt:`IMPORTED_LIBNAME` property.

Configuration names correspond to those provided by the project from
which the target is imported.
