ARCHIVE_OUTPUT_NAME_<CONFIG>
----------------------------

Per-configuration output name for
:ref:`ARCHIVE <Archive Output Artifacts>` target files.

This is the configuration-specific version of the
:prop_tgt:`ARCHIVE_OUTPUT_NAME` target property.
