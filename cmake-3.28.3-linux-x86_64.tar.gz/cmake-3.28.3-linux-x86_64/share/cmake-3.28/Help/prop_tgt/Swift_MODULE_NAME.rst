Swift_MODULE_NAME
-----------------

.. versionadded:: 3.15

This property specifies the name of the Swift module.  It is defaulted to the
name of the target.
