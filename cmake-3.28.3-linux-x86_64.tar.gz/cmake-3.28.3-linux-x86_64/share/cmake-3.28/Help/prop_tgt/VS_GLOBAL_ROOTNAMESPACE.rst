VS_GLOBAL_ROOTNAMESPACE
-----------------------

Visual Studio project root namespace.

Sets the "RootNamespace" attribute for a generated Visual Studio
project.  The attribute will be generated only if this is set.
